#!/sbin/sh
#
# Copyright (C) 2018 Kumar_Jy
#
# Made for PocophoneF1 (Beryllium)
#

mkdir /tmp/backup
dd if=/dev/block/by-name/fsc of=/tmp/backup/fsc
dd if=/dev/block/by-name/fsg of=/tmp/backup/fsg
dd if=/dev/block/by-name/modemst1 of=/tmp/backup/bootmodem_fs1
dd if=/dev/block/by-name/modemst2 of=/tmp/backup/bootmodem_fs2

umount /system
umount /data
umount /sdcard
umount /pe
umount /esp
umount /twrp

parted /dev/block/sda <<EOF
  rm 21
  rm 22
  rm 23
  rm 24
  rm 25
  rm 26
  mkpart userdata ext4 1611MB 100%
  quit
EOF

dd if=/cache/backup/fsc of=/dev/block/by-name/fsc
dd if=/cache/backup/fsg of=/dev/block/by-name/fsg
dd if=/cache/backup/bootmodem_fs1 of=/dev/block/by-name/modemst1
dd if=/cache/backup/bootmodem_fs2 of=/dev/block/by-name/modemst2

rm /sbin/parted
reboot recovery