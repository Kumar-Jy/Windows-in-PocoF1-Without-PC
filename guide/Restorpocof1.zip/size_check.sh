#!/sbin/sh
#
# Copyright (C) 2018 Kumar_Jy
#
# Made for Remove Windows from PocophoneF1 (Beryllium) 64GB/128GB/256GB
#

parted /dev/block/sda unit MB p quit -> /tmp/part

touch /tmp/size.prop
if grep "389MB" /tmp/part > /dev/null
then
  echo "data.size=389MB" >> /tmp/size.prop
  echo "data.type=Beryllium" >> /tmp/size.prop
else
  echo "data.size=unknown" >> /tmp/size.prop
  echo "data.type=unknown" >> /tmp/size.prop
fi

rm /tmp/part
