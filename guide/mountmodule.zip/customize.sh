
ui_print "  Auto mount at boot?"
ui_print "   Vol Up += Yes"
ui_print "   Vol Down += No"
chooseport() {
 while true; do
    local count=0
    while true; do
      timeout 5 /system/bin/getevent -lqc 1 2>&1 > $TMPDIR/events &
      sleep 0.5; count=$((count + 1))
      if (`grep -q 'KEY_VOLUMEUP *DOWN' $TMPDIR/events`); then
        return 0
      elif (`grep -q 'KEY_VOLUMEDOWN *DOWN' $TMPDIR/events`); then
        return 1
      fi
      [ $count -gt 6 ] && break
    done
done
}

if chooseport ; then
ui_print "auto mount enabled, flash again to change auto mount status"
else
ui_print "auto mount disabled, flash again to change auto mount status"
rm $MODULEPATH/service.sh
fi

echo "Congrats for using WoA"
echo "Magisk version: $MAGISK_VER ($MAGISK_VER_CODE)"
