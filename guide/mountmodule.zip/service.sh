while [[ -z $(ls /sdcard) ]]
do
    sleep 1
done

mkdir /mnt/sdcard/Windows || true
mkdir /mnt/sdcard/Winpe || true
mount -t ntfs /dev/block/by-name/win /mnt/sdcard/Windows || true
mount /dev/block/by-name/pe /mnt/sdcard/Winpe || true >> /data/local/tmp/log.txt 2>&1
