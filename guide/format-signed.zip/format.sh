#!/sbin/sh
#
# Copyright (C) 2018 Kumar_Jy
#
# Made for PocophoneF1  (Beryllium)
#

mkfs.fat -F32 -s1 /dev/block/by-name/pe 
mkfs.fat -F32 -s1 /dev/block/by-name/esp 
mkfs.ntfs -f /dev/block/by-name/win 
mke2fs -t ext4 /dev/block/by-name/userdata
