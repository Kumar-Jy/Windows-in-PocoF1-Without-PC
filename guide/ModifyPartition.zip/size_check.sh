#!/sbin/sh
#
# Copyright (C) 2018 Unlegacy Android Project
# Copyright (C) 2018 Svyatoslav Ryhel
#
# Made for install WINDOWS on PocophoneF1 (Beryllium) 64GB/128GB/256GB
#

parted /dev/block/sda unit GB p quit -> /tmp/part

touch /tmp/size.prop
if grep "123GB" /tmp/part > /dev/null
then
  echo "data.size=128GB" >> /tmp/size.prop
  echo "data.type=Beryllium128GB" >> /tmp/size.prop
else
  if grep "59.1MB" /tmp/part > /dev/null
  then
    echo "data.size=64GB" >> /tmp/size.prop
    echo "data.type=Beryllium64GB" >> /tmp/size.prop
  else
    if grep "250GB" /tmp/part > /dev/null
    then
      echo "data.size=256GB" >> /tmp/size.prop
      echo "data.type=Beryllium256GB" >> /tmp/size.prop
    else
	  echo "data.size=unknown" >> /tmp/size.prop
      echo "data.type=unknown" >> /tmp/size.prop
	fi
  fi
fi

rm /tmp/part
